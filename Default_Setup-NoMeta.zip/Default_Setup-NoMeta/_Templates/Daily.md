---

tags: Daily

---

# {{date:YYYY-MM-DD}}, {{time:HH:mm A}}

---

# Plans



# Thoughts



# Things that Happened



# Scratchpad

