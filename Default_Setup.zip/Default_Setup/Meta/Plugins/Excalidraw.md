---

tags: meta plugins

---

# Excalidraw

DRAWINGS! (Click on it to enter)

![[_Attachments/Excalidraw_2021-10-25 21.07.29.excalidraw.md|350]]

I always just press `Ctrl+Alt+Shift+E`, which automatically creates the document and places it into the current note (at cursor location). Then, when I'm done, I just go back with `Ctrl+Alt+LEFTARROW`.

Some of the images in the library are made by me, most are taken from the community library. 