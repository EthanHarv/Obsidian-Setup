---

tags: meta plugins

---

# Spaced Repitition

The concept itself: [Basics](https://ncase.me/remember/), [Detailed](https://www.gwern.net/Spaced-repetition)

The Plugin: [Github](https://github.com/st3v3nmw/obsidian-spaced-repetition)