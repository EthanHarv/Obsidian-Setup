---

tags: meta plugins

---

# Dataview

It's like SQL, but for obsidian!

``````
```dataview
TABLE file.size AS "Note Size" FROM #meta 
SORT file.size DESC
```
``````
Makes
```dataview
TABLE file.size AS "Note Size" FROM #meta 
SORT file.size DESC
```

Honestly, just go take a look at the [wiki](https://blacksmithgu.github.io/obsidian-dataview/intro/).