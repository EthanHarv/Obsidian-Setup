---

tags: meta plugins

---

# Advanced Tables

| Advanced        | tables:         | 
| --------------- | --------------- |
| Tables are hard | and hopefully   |
| this makes them | a little easier |

But honestly, I still avoid them.
I'm not even gonna *try* to explain how it works myself, because I'd probably do a poor job, so just reference [the github](https://github.com/tgrosinger/advanced-tables-obsidian).

I do use them much more with this than I would otherwise though, so I recommend trying it out at least.