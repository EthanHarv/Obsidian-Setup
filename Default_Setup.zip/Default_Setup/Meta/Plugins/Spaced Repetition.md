---

tags: meta plugins

---

# Spaced Repetition

I place most of my flashcards into the flashcards folder.

Essentially, spaced reptition is just flashcards, but at regular, increasing intervals so you remember stuff for longer.

Take a look at the [readme](https://github.com/st3v3nmw/obsidian-spaced-repetition) for more info, but the basics:

1. Mark a note with the `#flashcards` tag
2. Make a flashcard, see examples in [[Must remember...]]
3. Open the Spaced Repetition Modal
4. Learn