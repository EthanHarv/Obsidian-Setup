---

tags: meta plugins

---

# Paste URL into selection

Copy a URL. Select some text in editor mode. Paste the URL. It makes the `[text](https://example.com)`-style link automatically!