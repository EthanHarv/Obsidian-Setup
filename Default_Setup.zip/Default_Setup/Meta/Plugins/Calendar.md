---

tags: meta plugins

---

# Calendar

This plugin is about as simple as it gets—it's a calender that lives on the right side of your screen.

## [[Daily Notes]] Integration

A pretty cool (default!) behavior is that if you have an existing daily note for a date, clicking on that calender date will bring you to that note.