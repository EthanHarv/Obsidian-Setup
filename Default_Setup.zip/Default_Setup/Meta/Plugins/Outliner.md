---

tags: meta plugins

---

# Outliner

Outliner deals with
- Lists
    - of
    - items,
        - and
        - makes
        - handling
            - them
            - easier
    - wow!

Pretty much, just do `Ctrl+Shift+[UP/DOWN]` and it'll move items around.

It also makes it so `tab` and `shift+tab` work anywhere in the line for indenting/unindenting.