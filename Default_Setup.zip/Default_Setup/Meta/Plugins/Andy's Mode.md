---

tags: meta plugins

---

# Andy's Mode

Panels slide around!

Any time you open a wikilink with `Ctrl+Click`, it throws it onto the right side of your screen. As you go deeper and deeper into the node tree of notes, older ones will be pushed away to the left, and if you hold down `shift` and scroll, you can scroll between them.

## Test it!

Try `Ctrl+Click`-ing this [[Plugins]] link (or `Shift+Ctrl+Click` if you're in edit mode), and then do the same on `Daily Notes`, and the same on another link in there. The panels slide around!

## Why's it called Andy's mode?

It's based on [Andy Matuschak's](https://notes.andymatuschak.org/About_these_notes) notes.