```ad-abstract
title: Definition
collapse: open

<% tp.file.cursor(1) %>

```